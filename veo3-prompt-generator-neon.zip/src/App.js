import React, { useState } from "react";

const neonColors = {
  green: {
    color: "#39ff14",
    shadow: "0 0 10px #39ff14",
  },
  blue: {
    color: "#00ffff",
    shadow: "0 0 10px #00ffff",
  },
  red: {
    color: "#ff073a",
    shadow: "0 0 10px #ff073a",
  },
};

export default function App() {
  const [form, setForm] = useState({
    characterName: "",
    gender: "",
    age: "",
    ethnicity: "",
    physical: "",
    clothing: "",
    emotion: "",
    action: "",
    mainScene: "",
    duration: "",
    speed: "",
    mood: "",
    location: "",
    time: "",
    weather: "",
    season: "",
    music: "",
    backgroundSound: "",
    voiceover: "",
    cameraStyle: "",
    cameraMovement: "",
    framing: "",
    visualEffects: "",
    transition: "",
    onScreenText: "",
    colorFilter: "",
  });

  const [output, setOutput] = useState({ id: "", en: "" });
  const [themeColor, setThemeColor] = useState("green");

  const handleChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  const generatePrompt = () => {
    const idPrompt = `Seorang ${form.gender} ${
      form.age ? `berusia ${form.age}` : ""
    } dari ${form.ethnicity}, ${
      form.physical ? `berpenampilan ${form.physical},` : ""
    } mengenakan ${form.clothing}, sedang ${form.action} dengan ekspresi ${
      form.emotion
    }. Adegan utama berupa ${form.mainScene} berdurasi ${
      form.duration
    } dengan suasana ${form.mood} dan gerakan ${form.speed}. Berlatar ${
      form.location
    } pada ${form.time}, cuaca ${form.weather}, musim ${form.season}. Diiringi musik ${
      form.music
    }, suara latar ${form.backgroundSound}${
      form.voiceover ? `, dengan narasi: '${form.voiceover}'` : ""
    }. Kamera bergaya ${form.cameraStyle} dengan gerakan ${form.cameraMovement} dan framing ${
      form.framing
    }. Efek visual: ${form.visualEffects}, transisi: ${form.transition}, teks di layar: '${
      form.onScreenText
    }', filter warna: ${form.colorFilter}.`;

    const enPrompt = `A ${form.age} ${form.gender} from ${form.ethnicity}, with ${
      form.physical
    }, wearing ${form.clothing}, is ${form.action} with a ${
      form.emotion
    } expression. The main scene is ${form.mainScene}, lasting ${
      form.duration
    }, in a ${form.mood} mood with ${form.speed} motion. Set in ${
      form.location
    } during ${form.time}, weather is ${form.weather}, season is ${
      form.season
    }. Accompanied by ${form.music} music, background sound of ${
      form.backgroundSound
    }${
      form.voiceover ? `, with narration: '${form.voiceover}'` : ""
    }. Camera style is ${form.cameraStyle}, movement is ${form.cameraMovement}, framed as ${
      form.framing
    }. Visual effects: ${form.visualEffects}, transition: ${form.transition}, on-screen text: '${
      form.onScreenText
    }', color filter: ${form.colorFilter}.`;

    setOutput({ id: idPrompt, en: enPrompt });
  };

  const neon = neonColors[themeColor];

  return (
    <div
      style={{
        color: neon.color,
        backgroundColor: "#000",
        fontFamily: "monospace",
        padding: "20px",
        minHeight: "100vh",
      }}
    >
      <h1
        style={{
          textAlign: "center",
          textShadow: `0 0 5px ${neon.color}, 0 0 10px ${neon.color}`,
        }}
      >
        🎬 Veo3 Prompt Generator
      </h1>

      <div style={{ textAlign: "center", marginBottom: "20px" }}>
        <label>
          Pilih Tema Neon:
          <select
            value={themeColor}
            onChange={(e) => setThemeColor(e.target.value)}
            style={{
              marginLeft: "10px",
              backgroundColor: "#000",
              color: neon.color,
              borderColor: neon.color,
              borderWidth: "1px",
              padding: "5px",
            }}
          >
            <option value="green">Hijau</option>
            <option value="blue">Biru</option>
            <option value="red">Merah</option>
          </select>
        </label>
      </div>

      <input
        type="text"
        placeholder="Nama Karakter"
        value={form.characterName}
        onChange={(e) => handleChange("characterName", e.target.value)}
        style={{
          width: "100%",
          padding: "10px",
          marginBottom: "10px",
          backgroundColor: "#000",
          color: neon.color,
          borderColor: neon.color,
          borderWidth: "1px",
          borderRadius: "5px",
        }}
      />
      {/* You can add more inputs here as needed */}

      <button
        onClick={generatePrompt}
        style={{
          width: "100%",
          padding: "10px",
          backgroundColor: neon.color,
          color: "#000",
          borderColor: neon.color,
          borderWidth: "1px",
          cursor: "pointer",
          borderRadius: "5px",
          fontWeight: "bold",
          marginTop: "10px",
        }}
      >
        🎥 Generate Prompt
      </button>

      <div style={{ marginTop: "20px" }}>
        <h2
          style={{
            textAlign: "center",
            textShadow: `0 0 5px ${neon.color}, 0 0 10px ${neon.color}`,
          }}
        >
          📌 Prompt Bahasa Indonesia:
        </h2>
        <textarea
          value={output.id}
          readOnly
          rows="6"
          style={{
            width: "100%",
            padding: "10px",
            backgroundColor: "#000",
            color: neon.color,
            borderColor: neon.color,
            borderWidth: "1px",
            borderRadius: "5px",
          }}
        />
        <h2
          style={{
            textAlign: "center",
            textShadow: `0 0 5px ${neon.color}, 0 0 10px ${neon.color}`,
          }}
        >
          🌐 English Prompt:
        </h2>
        <textarea
          value={output.en}
          readOnly
          rows="6"
          style={{
            width: "100%",
            padding: "10px",
            backgroundColor: "#000",
            color: neon.color,
            borderColor: neon.color,
            borderWidth: "1px",
            borderRadius: "5px",
          }}
        />
      </div>
    </div>
  );
}